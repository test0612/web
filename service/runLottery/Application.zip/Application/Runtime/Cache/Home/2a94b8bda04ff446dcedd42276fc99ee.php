<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=utf-8">
<script src="Public/js/jquery.js"></script>
<script>
var status = 'stop';
var loadnum = 0;
var loadurl = "<?=U('Home/Index/getLotteryResult')?>";
var startdate = '';
$(function(){
	var t = getTime();
 
	window.setInterval(oneSecond, 1000); 
	$("#theButton").click(function(){theButton(this)});
});
function oneSecond() { 
	getNow();
	nexttime();
} 
function getTime(){
	var myDate = new Date();
	return myDate.toLocaleString(); 
}
function getNow(){
	var t = getTime();
	$(".now").html(t);
}
function nexttime(){
	if(status == 'running'){
		 
		var t = $("#nexttime").html();
		--t;
		if(t <= 0 ){
			t = $("#frequency").val();
			proload();
		}
		$("#nexttime").html(t);
	}
}
//启动
function theButton(obj){
	
	var val = $(obj).val();
	if(val == '启动'){
		startdate = getTime();
		$("#startdate").html(startdate);
		prostart();
		val = '停止';
	}else{
		prostop();
		val = '启动';
	}
	$(obj).val(val);
}
//开始
function prostart(){
	//$("#prostatus").show();
	
	proload();
}
//停止
function prostop(){
	startdate = '';
	status = 'stop';
	loadnum = 0;
	//$("#prostatus").hide();
}
//读取
function proload(){
	status = 'running';
	//var cv = $('input:radio[name=laiyuan]:checked').val();
	//alert(cv);
	$("#loadstatus").html('Loading...');
	$("#nexttime").html($("#frequency").val());
	//var param = {'laiyuan':cv}
	var param = {}
	$.get(loadurl,param,function(d){
		 
		prosuccess();   
 
	});
}

function prosuccess(){
	$("#loadstatus").html('采集完毕!');
	loadnum++;
	$("#loadnum").html(loadnum);
}
</script>
</head>
<body style="width:50000px"> 
<table>
<tr>

<td>当前时间:&nbsp;&nbsp;</td><td><span class='now'></span></td>
</tr><tr>
<td>设定频率:&nbsp;&nbsp;</td><td><input type='text' style="width:50px" class='frequency' id="frequency" value="10" />秒</td>
</tr>

<tr>
<td>操作:&nbsp;&nbsp;</td><td><input type="button" value="启动" name="button" id="theButton" /></td>
</tr>
</table>
<div>
<table id="prostatus">
<tr>
<td>状态：</td><td id='loadstatus'></td>
</tr>
<tr>
<td>下次读取：</td><td ><span id='nexttime'></span>&nbsp;&nbsp;&nbsp;&nbsp;<!--<input type="button" value="立即执行" name="button" id="proload" />--></td>
</tr>
<tr>
 
</tr>
<tr>
<td>开始时间：</td><td ><span id='startdate'></span></td>
</tr>
<tr>
<td>当前来源地址</td>
<td>
<input type="radio" name="laiyuan" value="lecai" checked /> lecai.com
<input type="radio" name="laiyuan" value="caipiao163" checked /> caipiao163.com
</td>
</tr>
</table>
<table>

</table>
</div>
</body>
<style>
.tcenter{
	text-align:center;
}
.w200{
	width:200px;
}
.w65{
	width:65px;
}
.now{
	color:red;
	font-size:14px;
 
}
#prostatus{
	 
}
</style>
</html>